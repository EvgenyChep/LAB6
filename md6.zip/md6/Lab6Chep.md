Лабораторная работа 6
Выполнил: Чепыгов Евгений

Цель работы: научиться вычислять примеры в Octave
Ход выполнения работы:
1. Вычисляем пределы
![](C:\Users\evgen\Desktop\лаб\1.png)

![](C:\Users\evgen\Desktop\лаб\2.png)
![](C:\Users\evgen\Desktop\лаб\3.png)
2. Вычисляем пример частичной суммы с графиком
![](C:\Users\evgen\Desktop\лаб\4.png)
![](C:\Users\evgen\Desktop\лаб\5.png)
![](C:\Users\evgen\Desktop\лаб\6.png)



3. Решаем пример суммы ряда
![](C:\Users\evgen\Desktop\лаб\7.png)

![](C:\Users\evgen\Desktop\лаб\8.png)
4.Решаем интеграл
![](C:\Users\evgen\Desktop\лаб\9.png)
![](C:\Users\evgen\Desktop\лаб\10.png)
5. Создаем алгоритм решения примера с интегралом
![](C:\Users\evgen\Desktop\лаб\11.png)
![](C:\Users\evgen\Desktop\лаб\12.png)
![](C:\Users\evgen\Desktop\лаб\13.png)
Выводы: в этой работе я научиться вычислять примеры в Octave
